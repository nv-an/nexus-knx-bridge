# Kế hoạch "Giải phóng" AI Agent (Gemini) cho KNX Bridge

## Tin vui cho bạn!
Trong lúc phân tích cấu trúc hệ thống, tôi phát hiện ra **bạn ĐÃ CÓ SẴN bộ não Gemini đang chạy ngầm rồi!** 
Cái `openclaw-gateway.service` của bạn đã được cấu hình biến môi trường `GEMINI_API_KEY` (trong thư mục `.config/systemd/user/openclaw-gateway.service.d/10-gemini-key.conf`). Tức là nền tảng OpenClaw của bạn hiện tại chính là một AI Agent chạy bằng Gemini.

## Vậy tại sao trước giờ bot không biết "suy luận"?
Mặc dù bạn có Gemini, nhưng hệ thống lại bị **"trói tay trói chân" bởi quá nhiều code cứng (hardcode)**:
1. **Trong Plugin Zalo (`monitor-BcYKNoj4.js`)**: Có ai đó đã chế thêm đoạn code bắt buộc gõ chữ `doc_read <link>` rồi chạy script bằng `child_process`. Đoạn code này chặn đứng tin nhắn, không cho Gemini đọc và suy luận.
2. **Trong KNX Bridge (`app.py`)**: Tương tự, endpoint `/agent/command` tự lấy tin nhắn ra phân tích bằng chuỗi cứng nhắc (`if "bật" in t`), biến Gemini thành kẻ thừa.
3. **Trong `AGENTS.md`**: Có luật cấm Gemini suy luận: *"If the user message starts with doc_knx, do not answer from memory... Forward the exact user text to KNX Bridge"*.

=> Hệ quả: Gemini chỉ đóng vai trò bù nhìn, mọi thứ vẫn chạy bằng lệnh `if/else` thủ công!

---

## Các bước triển khai (Implementation Plan)

Mục tiêu: Xóa bỏ các rào cản code cứng, đưa toàn bộ quyền kiểm soát lại cho Gemini để nó đọc link, chạy script Python, đọc file JSON và chat trực tiếp với bạn.

### Bước 1: Dọn dẹp Plugin Zalo (`monitor-BcYKNoj4.js`)
- **[Hành động]**: Tôi sẽ khôi phục file `monitor-BcYKNoj4.js` về phiên bản gốc (xóa các hàm `doc_read` và `doc_knx` bị hardcode).
- **[Kết quả]**: Khi bạn gửi link Google Drive/Sheet vào Zalo, link sẽ được chuyển thẳng nguyên vẹn đến não của Gemini.

### Bước 2: Tối ưu hóa "Nhân cách" trong `AGENTS.md`
- **[Hành động]**: Xóa bỏ các luật cấm đoán (`Critical Routing Rule: doc_knx`).
- Viết lại Prompt cho Gemini như sau:
  - *"Khi người dùng gửi link tài liệu KNX, hãy sử dụng Tool Terminal để chạy lệnh: `python tools/document_to_knx_skill.py <link>`"*
  - *"Sau khi chạy xong, hãy dùng Tool đọc file để đọc file proposal JSON vừa được tạo ra ở `knowledge/review/`."*
  - *"Dựa vào dữ liệu trong file đó, tự động tóm tắt lại cho người dùng bằng tiếng Việt tự nhiên và hỏi họ muốn thêm thiết bị nào vào KNX Bridge."*
  - *"Khi họ đồng ý, chạy lệnh `python tools/apply_device_proposal.py ...`"*

### Bước 3: Dọn dẹp API `/agent/command` trong `app.py`
- Thay vì để `app.py` tự nhận diện `bật/tắt`, ta sẽ sửa lại `AGENTS.md` để Gemini tự gọi thẳng vào các API có cấu trúc rõ ràng như `/light`, `/devices/add`, `/context`.

---

> [!IMPORTANT]
> - Bạn sẽ **không gửi file trực tiếp** qua Zalo (vì Proxy Zalo của bạn xóa mất file). Bạn chỉ cần upload file lên Google Drive/Sheet, share link dạng "Anyone with the link", rồi gửi cái link đó vào Zalo.
> - Gemini sẽ nhận cái link đó, "ồ, đây là link tài liệu KNX", tự bật terminal tải về, tự phân tích, tự hỏi bạn.
> 
> Bạn có đồng ý với phương án dọn dẹp hệ thống để giao toàn quyền cho Gemini như thế này không?
