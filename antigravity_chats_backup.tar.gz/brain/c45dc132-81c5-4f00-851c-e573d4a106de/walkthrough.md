# Di dời Zalo Bot & KNX-Bridge sang Raspberry Pi thành công

## Những thay đổi đã thực hiện

Hôm nay, chúng ta đã tiến hành một đợt "chuyển nhà" lớn, chuyển toàn bộ "não bộ" của hệ thống nhà thông minh từ máy tính bàn (Laptop) sang một máy tính nhúng (Raspberry Pi 4) để đảm bảo hệ thống có thể chạy 24/7 mà không tốn điện.

1. **Cài đặt môi trường độc lập**
   - Đóng gói toàn bộ cấu hình OpenClaw, 9Router và source code KNX-Bridge.
   - Cài đặt `node.js` và tạo Python `venv` độc lập trên Pi để tránh xung đột hệ thống.

2. **Khắc phục lỗi kiến trúc chip (x86 vs ARM64)**
   - Phát hiện và loại bỏ các file mạng (`cloudflared`) dành riêng cho chip máy tính cũ.
   - Ép hệ thống Pi tự động tải lại và biên dịch các "cánh tay" (Zalo Plugin, Groq Provider) tương thích hoàn toàn với kiến trúc ARM.

3. **Di dời cầu nối mạng (Ngrok)**
   - Phát hiện lỗi đường ống mạng bị kẹt ở Laptop.
   - Cài đặt Ngrok lên Pi qua Snap.
   - Thiết lập dịch vụ ngầm `ngrok.service` để khóa cứng tên miền Webhook Zalo vào cổng OpenClaw của Pi.

## Kết quả nghiệm thu

> [!TIP]
> Tất cả 4 dịch vụ cốt lõi hiện đang chạy ngầm trên Pi như những bóng ma:
> 1. `knx-bridge.service`: Quản lý sóng KNX.
> 2. `9router.service`: Quản lý AI proxy tốc độ cao.
> 3. `openclaw-gateway.service`: Quản lý nhân cách Bot và kết nối Zalo.
> 4. `ngrok.service`: Quản lý luồng tin nhắn ra vào từ Internet.

Hệ thống đã chính thức trở thành một cỗ máy tự trị 100%. Bạn có thể tắt hoàn toàn máy tính làm việc và tận hưởng hệ thống Smart Home ổn định!
