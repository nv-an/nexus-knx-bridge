# Di dời Ngrok sang Raspberry Pi

Dự án hiện tại đang phụ thuộc vào máy tính (Laptop) để chạy Ngrok, đóng vai trò như cầu nối mạng nhận tin nhắn từ Zalo. Mục tiêu của kế hoạch này là bứng toàn bộ cấu trúc Ngrok sang Raspberry Pi, giúp Pi hoạt động hoàn toàn độc lập 100%.

## User Review Required

> [!IMPORTANT]
> Plan này sẽ yêu cầu bạn dán một đoạn mã cài đặt dài vào Terminal của Pi. Khi chạy xong, máy tính (Laptop) của bạn sẽ chính thức được "nghỉ ngơi" hoàn toàn. Zalo sẽ gửi tin thẳng vào Pi. Bạn có đồng ý triển khai không?

## Proposed Changes

Chúng ta sẽ thực hiện các thay đổi sau trên **Raspberry Pi**:

1. **Cài đặt Ngrok (ARM64)**
   - Thêm repository chính thức của Ngrok cho Ubuntu 24.04 trên cấu trúc ARM64.
   - Cài đặt gói `ngrok`.

2. **Xác thực Ngrok**
   - Nạp Authtoken của bạn (`3FFIlN...`) vào thiết bị Pi.

3. **Cấu hình Systemd Service**
   - Tạo file dịch vụ ngầm `ngrok.service` để Ngrok tự động chạy và giữ kết nối với tên miền `jogger-outdoors-silica.ngrok-free.dev` trỏ vào cổng `18789` của OpenClaw ngay cả khi Pi khởi động lại.

## Verification Plan

### Manual Verification
- Tắt ngrok trên Laptop.
- Dán lệnh cấu hình vào Pi.
- Dùng điện thoại gửi tin nhắn Zalo cho Bot. Nếu Bot phản hồi, có nghĩa là đường ống mạng Ngrok đã được thiết lập thành công trực tiếp trên Pi.
