# Plan
- [x] Open http://localhost:8080 (FAILED: failed to create browser context: failed to create browser instance: wrong CDP URL: invalid CDP URL)
- [ ] Wait 2 seconds for charts to render
- [ ] Select "Yangon" from City filter
- [ ] Wait 1 second
- [ ] Select "Member" from Customer Type filter
- [ ] Wait 1 second
- [ ] Click "Reset Filters"
- [ ] Wait 1 second
- [ ] Finish and report success

