# Hoàn thiện: Professional Supermarket Sales Dashboard

Toàn bộ các tệp mã nguồn theo yêu cầu khắt khe và chi tiết của bạn đã được khởi tạo thành công tại thư mục `/home/an/SIC_AI/`.

## 📦 Các tệp đã xây dựng

1.  **[index.html](file:///home/an/SIC_AI/index.html)**:
    *   Tái cấu trúc HTML5 với Sidebar bộ lọc tĩnh, Header, 4 KPI cards, 5 Insight cards.
    *   Lưới (Grid) chứa 6 canvas biểu đồ.
    *   Khu vực Bảng dữ liệu có thanh tìm kiếm và điều hướng phân trang (Pagination).
2.  **[style.css](file:///home/an/SIC_AI/style.css)**:
    *   Hệ màu Dark Mode cao cấp (màu nền Navy, Slate), font Inter.
    *   Sử dụng CSS Grid và Flexbox để dàn trang Responsive.
    *   Xây dựng hiệu ứng Glassmorphism tinh tế cho tất cả các Panel.
    *   Xử lý Overlay làm mờ biểu đồ và bảng khi `No data available`.
3.  **[app.js](file:///home/an/SIC_AI/app.js)**:
    *   Logic hoạt động như một ứng dụng React/Vue (Dữ liệu -> Trạng thái -> Render UI).
    *   Hỗ trợ đọc Date chuẩn xác, tự động giới hạn ngày tháng bộ lọc.
    *   *City & Branch Liên kết*: Lọc cực thông minh, chọn Yangon là tự nhảy qua Branch A và ngược lại.
    *   *Dynamic Previous Period KPIs*: Thuật toán tính toán thông minh tự tìm dữ liệu của "kỳ trước" bằng với số ngày đang lọc để đưa ra số % Tăng/Giảm (màu Xanh/Đỏ).
    *   Xử lý phân trang mượt mà (Hiển thị `Showing 1 to 50 of 1000 entries`).
4.  **[README.md](file:///home/an/SIC_AI/README.md)**:
    *   Tài liệu hướng dẫn cách chạy Local Server và tính năng chi tiết.

## 🚀 Cách chạy và Kiểm tra

Vì chúng ta sử dụng PapaParse đọc File qua Javascript, **bạn KHÔNG THỂ nhấp đúp file HTML** (do lỗi bảo mật CORS của trình duyệt).

Thay vào đó, hãy làm theo hướng dẫn sau trong Terminal:

```bash
cd /home/an/SIC_AI
python3 -m http.server 8000
```

Sau đó, truy cập vào `http://localhost:8000` trên trình duyệt để thưởng thức thành quả!

> [!TIP]
> Hãy thử thay đổi bộ lọc Date From/To, sau đó nhìn vào các con số ở thẻ KPI (Tổng doanh thu, Lợi nhuận) để thấy % biến động so với khoảng thời gian liền trước nhảy số mượt mà! Thử bấm "Export Filtered Data" để tải file CSV kết quả về máy nhé.
