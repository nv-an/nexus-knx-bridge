# Kế Hoạch Tự Động Hóa Xoay Key & Quản Lý Trí Nhớ (Auto-Failover & Auto-Compaction)

Để giải quyết triệt để 2 vấn đề sếp vừa nêu (Tự động xoay Key khi sập mạng và tự động dọn rác lịch sử), tôi đề xuất phương án can thiệp thẳng vào hệ thống quản lý Context và Model Routing của OpenClaw Gateway.

## User Review Required

Sếp xem qua giải pháp bên dưới. Nếu sếp ưng ý, tôi sẽ triển khai cấu hình ngay lập tức!

## 1. Tự Động Xoay Key (Model Failover)

Thay vì gán chết một chìa khóa, ta sẽ cấu hình **Hệ Thống Trạm Trung Chuyển (Fallback Chain)**. Khi chìa khóa chính (Gemini) bị Google báo lỗi hết lượt (Limit 429), hệ thống sẽ không treo nữa mà âm thầm, tự động nhảy số sang chìa khóa dự phòng trong chưa tới 1 giây.

**Luồng ưu tiên:**
1. **Chính (Primary):** `google/gemini-2.5-flash` (Nhanh, thông minh).
2. **Dự phòng 1 (Fallback 1):** `groq/llama-3.3-70b-versatile` (Nhanh nhất thế giới, chống cháy cực tốt).
3. **Dự phòng 2 (Fallback 2):** `openai/meta/llama-3.3-70b-instruct` (NVIDIA NIM - Xài tạm nếu cả 2 thằng kia cùng sập).

*Lợi ích:* Sếp sẽ không bao giờ biết được lúc nào API bị sập, vì bot luôn trả lời được mọi lúc mọi nơi nhờ cơ chế nhảy dù tự động này.

## 2. Tự Động Xóa Rác Lịch Sử (Aggressive Compaction)

Gemini có bộ nhớ 1 triệu chữ, nhưng ta **TUYỆT ĐỐI KHÔNG** cho nó xài hết. Ta sẽ "lừa" hệ thống OpenClaw bằng cách khai báo rằng bộ nhớ của Gemini chỉ chứa được đúng **4000 chữ (4k tokens)**.

**Cơ chế hoạt động:**
- Bất cứ khi nào tổng số chữ của cuộc hội thoại vượt mức 3000 chữ, hệ thống Auto-Compaction của OpenClaw sẽ tự động kích hoạt.
- Nó sẽ thẳng tay chặt bỏ toàn bộ các tin nhắn cũ rích ở đầu cuộc hội thoại và chỉ giữ lại những đoạn chat gần nhất.
- *Lợi ích:* Con bot luôn trong trạng thái "não nhẹ tênh", không bao giờ phải gánh đống rác 25,000 chữ nữa. Tốc độ sẽ luôn duy trì ở mức dưới 3-4 giây phản hồi, và sếp không bao giờ phải gõ lệnh `/new` bằng tay nữa.

## 3. Các Bước Triển Khai Thực Tế

### [MODIFY] `/home/an/.openclaw/openclaw.json`
- Chỉnh sửa thuộc tính `model` của agent `main` từ chuỗi (string) thành một Object chứa `primary` và `fallback`.
- Bổ sung trường `"contextWindow": 4096` vào cấu hình của provider `google` để ép hệ thống dọn rác sớm.

## Verification Plan
1. Kiểm tra file cấu hình JSON xem có lỗi cú pháp không trước khi khởi động.
2. Restart `openclaw-gateway`.
3. Gửi lệnh dài để test tính năng Auto-Compaction.
