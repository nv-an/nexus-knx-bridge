from xknx.dpt import Switch
print(f"Switch.ON truthiness: {bool(Switch.ON)}")
print(f"Switch.OFF truthiness: {bool(Switch.OFF)}")
