import asyncio
from xknx import XKNX
from xknx.io import ConnectionConfig, ConnectionType
from xknx.tools import read_group_value

async def main():
    connection_config = ConnectionConfig(
        connection_type=ConnectionType.TUNNELING,
        gateway_ip="10.1.10.137",
        gateway_port=3671,
        local_ip="10.1.10.92"
    )
    xknx = XKNX(connection_config=connection_config)
    await xknx.start()
    try:
        val = await read_group_value(xknx, "0/0/2", value_type="switch")
        print(f"Value: {val}")
        print(f"Type: {type(val)}")
    finally:
        await xknx.stop()

if __name__ == "__main__":
    asyncio.run(main())
