# Tổng quan Kiến trúc Hệ thống: Zalo AI Smarthome (KNX)

Tài liệu này mô tả chi tiết cấu trúc hiện tại của hệ thống điều khiển nhà thông minh (KNX) thông qua Zalo Chatbot, sử dụng bộ não AI từ NVIDIA NIM và được điều phối bởi OpenClaw Gateway. Tài liệu được biên soạn để thuận tiện cho việc đánh giá, phân tích kỹ thuật và mở rộng sau này.

---

## 1. Sơ đồ Kiến trúc Tổng thể (High-level Architecture)

Hệ thống được chia thành 4 lớp (Layers) chính, giao tiếp với nhau theo thời gian thực:

```mermaid
graph TD
    User([Người dùng Zalo]) <-->|Webhook/Chat| ZaloOA(Zalo Official Account)
    ZaloOA <-->|ngrok tunnel| OpenClaw(OpenClaw Gateway)
    
    subgraph Lớp AI & Điều phối
        OpenClaw <-->|POST /v1/chat/completions| NVIDIA(NVIDIA NIM API)
        OpenClaw -->|Thực thi Tools/Kỹ năng| Tools[Bộ Kỹ Năng / Skills]
    end

    subgraph Lớp IoT / Local Bridge
        Tools <-->|HTTP REST / WebSocket| KNXBridge(KNX Bridge - FastAPI)
    end
    
    subgraph Lớp Phần cứng (KNX)
        KNXBridge <-->|Giao thức KNX/IP Tunneling| KNXGateway(KNX IP Gateway)
        KNXGateway --> Lights[Đèn]
        KNXGateway --> Sensors[Cảm biến / Thời tiết]
    end
```

---

## 2. Chi tiết các Thành phần Cốt lõi (Core Components)

### A. Lớp Tương tác (Interface Layer)
- **Zalo Official Account (OA)**: Điểm tiếp xúc duy nhất với người dùng. Nhận tin nhắn (text, voice) và gửi về hệ thống cục bộ.
- **Ngrok Tunnel**: Mở một cổng bảo mật từ Localhost ra Internet (ví dụ: `https://...ngrok-free.dev/zalo`) để Zalo OA có thể đẩy (Push) Webhook payload về máy chủ nội bộ.

### B. Lớp Điều phối AI (Orchestration Layer) - OpenClaw Gateway
- **Công nghệ**: Node.js (`openclaw-gateway.service`).
- **Nhiệm vụ**: Đóng vai trò là bộ não trung tâm (Agent Hub). Quản lý lịch sử trò chuyện (session memory), phân tích ngữ cảnh, quyết định gọi các công cụ (Tool calling) và điều hướng luồng giao tiếp.
- **Cấu hình Model hiện tại (`openclaw.json`)**:
  - **Provider**: `openai` (Sử dụng module `openai-completions` để tương thích ngược với chuẩn `/chat/completions` truyền thống, bỏ qua chuẩn `/responses` khắt khe).
  - **Endpoint**: `https://integrate.api.nvidia.com/v1`
  - **Model**: `meta/llama-3.3-70b-instruct` (NVIDIA NIM).
  - **Lợi ích**: Tận dụng tốc độ suy luận siêu nhanh của NVIDIA NIM, tránh hoàn toàn vấn đề giới hạn Rate Limit của các nền tảng miễn phí (như Groq).

### C. Lớp Cầu nối IoT (Local Bridge Layer) - `knx-bridge/app.py`
- **Công nghệ**: Python, FastAPI, thư viện `xknx`.
- **Nhiệm vụ**: Là một Middleware dịch các mệnh lệnh bằng ngôn ngữ tự nhiên (đã được AI phân tích thành Tool Call) sang các lệnh điều khiển phần cứng KNX.
- **Tính năng nổi bật**:
  - **Quản lý thiết bị (`devices.json`)**: Lưu trữ địa chỉ nhóm (Group Address) của các đèn, công tắc, cảm biến.
  - **API Endpoints**: Cung cấp các REST API cục bộ (VD: `GET /status`, `POST /control`) để OpenClaw Tools có thể gọi vào.
  - **Tự động hóa ngầm (Background Tasks)**: Tích hợp vòng lặp kiểm tra thời tiết thực tế để tự động điều khiển các kịch bản ánh sáng giả lập (ví dụ: `den_e`, `den_f`).
  - **Khắc phục sự cố mạng**: Tự động phát hiện IP máy chủ (`local_ip`) để xử lý triệt để lỗi cạn kiệt kết nối KNX IP Tunneling (`OSError: [Errno 99]`).

### D. Lớp Phần cứng (Hardware Layer) - KNX
- **Công nghệ**: Chuẩn nhà thông minh KNX.
- **Kết nối**: Giao tiếp qua mạng LAN nội bộ tới địa chỉ `10.1.10.137` ở cổng `3671`.

---

## 3. Điểm nhấn Kỹ thuật & Quyết định Kiến trúc (Design Decisions)

1. **Khắc phục lỗi Tương thích OpenAI API (NVIDIA 404 Error)**:
   - Thay vì thiết lập hệ thống Proxy rườm rà để ép NVIDIA NIM hiểu chuẩn `POST /responses` của OpenAI SDK mới, hệ thống đã được tinh chỉnh để OpenClaw sử dụng định dạng `openai-completions`. Quyết định này giúp kiến trúc gọn nhẹ, giảm độ trễ (latency) và tránh "điểm mù" (single point of failure) do Proxy cục bộ gây ra.
2. **Decoupled Architecture (Kiến trúc phân tách)**:
   - Việc tách bạch AI Orchestrator (OpenClaw) và Hardware Controller (KNX Bridge) giúp hệ thống cực kỳ linh hoạt. Nếu OpenClaw sập, hệ thống tự động hóa KNX cục bộ (như tính năng mô phỏng thời tiết) vẫn tiếp tục hoạt động độc lập qua FastAPI.
3. **Web Search Provider**:
   - Chuyển đổi từ `gemini` sang `duckduckgo` cho tính năng tìm kiếm web của Agent, giúp tiết kiệm Quota API mà vẫn đảm bảo bot được tiếp cận thông tin thời gian thực.

---

## 4. Các điểm cần lưu ý khi mở rộng (Future Considerations)

- **Bảo mật**: Hiện tại Zalo Webhook đang được Expose qua ngrok. Khi đưa lên môi trường Production thực tế, nên triển khai Reverse Proxy (Nginx/Traefik) với Cloudflare Tunnel hoặc IP tĩnh + SSL để ổn định hơn.
- **KNX Connection Pooling**: Thư viện `xknx` đôi khi bị giới hạn số lượng Tunnel (thường là 4-5 tunnel tùy thuộc vào KNX IP Interface). Cần theo dõi log để đảm bảo `app.py` không mở quá nhiều kết nối rác mà không đóng lại (Connection Exhaustion).
- **Log Management**: Khuyến nghị thiết lập hệ thống thu thập log tập trung (VD: Loki hoặc ELK) thay vì chỉ dùng `journalctl` để dễ dàng truy vết khi Zalo Bot phản hồi chậm.
