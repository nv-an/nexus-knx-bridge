Title: Public APIs - Thư viện API miễn phí cho lập trình viên

Description: Khám phá hàng nghìn API công khai miễn phí cho lập trình viên: tìm kiếm, lọc theo xác thực / HTTPS / CORS, và lưu API yêu thích. Dữ liệu từ public-apis.

Source: https://apis.j2team.org/

---

[Nguồn: public-apis](https://github.com/public-apis/public-apis)
[J2TEAM Security Chặn web lừa đảo & bảo vệ tài khoản](https://j2team.org/install)
[J2TEAM Cookies Xuất / nhập cookies trình duyệt](https://chromewebstore.google.com/detail/j2team-cookies/okpidcojinmlaakglciglbpcpajaibco)
[J2TEAM TTS Văn bản thành giọng nói tự nhiên](https://store.j2team.org/)

[0x](https://0x.org/api)
API for querying token and pool stats across various liquidity pools
[18F](http://18f.github.io/API-All-the-X/)
Unofficial US Federal Government API Development
[1Forge](https://1forge.com/forex-data-api/api-documentation)
Forex currency market data
[1inch](https://1inch.io/api/)
API for querying decentralize exchange
[1pt](https://github.com/1pt-co/api/blob/main/README.md)
A simple URL shortener
[24 Pull Requests](https://24pullrequests.com/api)
Project to promote open source collaboration during December
[4chan](https://github.com/4chan/4chan-API)
Simple image-based bulletin board dedicated to a variety of topics
[7digital](https://docs.7digital.com/reference)
Api of Music store 7digital
[7Timer!](http://www.7timer.info/doc.php?lang=en)
Weather, especially for Astroweather
[A Bíblia Digital](https://www.abibliadigital.com.br/en)
Do not worry about managing the multiple versions of the Bible
[AbuseIPDB](https://docs.abuseipdb.com/)
IP/domain/URL reputation
[AccuWeather](https://developer.accuweather.com/apis)
Weather and forecast data
[AcreLens](https://www.acrelens.com)
Land suitability scoring API for any US property: off-grid, rural, recreational, investment
[Actinia Grass GIS](https://actinia.mundialis.de/api_docs/)
Actinia is an open source REST API for geographical data that uses GRASS GIS
[administrative-divisons-db](https://github.com/kamikazechaser/administrative-divisions-db)
Get all administrative divisions of a country
[AdoptAPet](https://www.adoptapet.com/public/apis/pet_list.html)
Resource to help get pets adopted
[adresse.data.gouv.fr](https://adresse.data.gouv.fr)
Address database of France, geocoding and reverse
[ADS-B Exchange](https://www.adsbexchange.com/data/)
Access real-time and historical data of any and all airborne aircraft
[Advice Slip](http://api.adviceslip.com/)
Generate random advice slips
[Adzuna](https://developer.adzuna.com/overview)
Job board aggregator
[Aemet](https://opendata.aemet.es/centrodedescargas/inicio)
Weather and forecast data from Spain
[Aftership](https://developers.aftership.com/reference/quick-start)
API to update, manage and track shipment efficiently
[Agify.io](https://agify.io)
Estimates the age from a first name
[AI Dev Jobs](https://aidevboard.com/openapi.yaml)
AI/ML engineering job aggregator with REST, RSS, and MCP endpoints
[AI For Thai](https://aiforthai.in.th/index.php)
Free Various Thai AI API
[AI Mastering](https://aimastering.com/api_docs/)
Automated Music Mastering
[airportsapi](https://airport-web.appspot.com/api/docs/)
Get name and website-URL for airports by ICAO code
[Airtable](https://airtable.com/api)
Integrate with Airtable
[Airtel IP](https://sys.airtel.lv/ip2country/1.1.1.1/?full=true)
IP Geolocation API. Collecting data from multiple sources
[AIS Hub](http://www.aishub.net/api)
Real-time data of any marine and inland vessel equipped with AIS tracking system
[Alchemy Ethereum](https://docs.alchemy.com/alchemy/)
Ethereum Node-as-a-Service Provider
[Aletheia](https://aletheiaapi.com/)
Insider trading data, earnings call analysis, financial statements, and more
[AlienVault Open Threat Exchange (OTX)](https://otx.alienvault.com/api)
IP/domain/URL reputation
[Alpaca](https://alpaca.markets/docs/api-documentation/api-v2/market-data/alpaca-data-api-v2/)
Realtime and historical market data on all US equities and ETFs
[Alpha (Mossland)](https://alpha.moss.land/developers)
Korean crypto channel stance + RAG Q&A + canonical entity/topic/event store
[Alpha Vantage](https://www.alphavantage.co/)
Realtime and historical stock data
[Amadeus for Developers](https://developers.amadeus.com/self-service)
Travel Search - Limited usage
[Amanah Sunnah](https://sunnah.amanahagent.cloud/developers)
Semantic search across Quran, Hadith, Tafsir & 18K+ Rijal narrators
[Amazonscraperapi](https://amazonscraperapi.com)
Amazon product, search & batch scraping API with residential proxies (1000 free)
[Amdoren](https://www.amdoren.com/currency-api/)
Free currency API with over 150 currencies
[Améthyste](https://api.amethyste.moe/)
Generate images for Discord users
[AmiiboAPI](https://amiiboapi.com/)
Nintendo Amiibo Information
[An API of Ice And Fire](https://anapioficeandfire.com/)
Game Of Thrones API
[AniAPI](https://aniapi.com/docs/)
Anime discovery, streaming & syncing with trackers
[AniDB](https://wiki.anidb.net/HTTP_API_Definition)
Anime Database
[AniList](https://github.com/AniList/ApiV2-GraphQL-Docs)
Anime discovery & tracking

[Animal Crossing: New Horizons](http://acnhapi.com/)
API for critters, fossils, art, music, furniture and villagers
[AnimeChan](https://github.com/RocktimSaikia/anime-chan)
Anime quotes (over 10k+)
[AnimeFacts](https://chandan-02.github.io/anime-facts-rest-api/)
Anime Facts (over 100+)
[AnimeNewsNetwork](https://www.animenewsnetwork.com/encyclopedia/api.php)
Anime industry news
[Anycrap](https://anycrap.shop/developers)
35,000+ absurdist AI-generated product concepts with names, descriptions, and images
[Apache Superset](https://superset.apache.org/docs/api)
API to manage your BI dashboards and data sources on Superset
[API Grátis](https://apigratis.com.br/)
Multiples services and public APIs
[API Setu](https://www.apisetu.gov.in/)
An Indian Government platform that provides a lot of APIS for KYC, business, education & employment
[API-FOOTBALL](https://www.api-football.com/documentation-v3)
Get information about Football Leagues & Cups
[Api2Convert](https://www.api2convert.com/)
Online File Conversion API
[ApicAgent](https://www.apicagent.com)
Extract device details from user-agent string
[ApiFlash](https://apiflash.com/)
Chrome based screenshot API for developers
[Apiip](https://apiip.net/)
Get location information by IP address
[apilayer aviationstack](https://aviationstack.com/)
Real-time Flight Status & Global Aviation Data API

