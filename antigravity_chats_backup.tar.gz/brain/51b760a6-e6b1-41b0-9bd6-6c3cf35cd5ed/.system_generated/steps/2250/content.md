Title: 9Router - Free AI Router | Smart Fallback for Claude, Codex & More

Source: https://9router.com/

---

[hub9Router](https://9router.com/)

[Providers](https://9router.com/#providers)
[Tools](https://9router.com/#tools)
[Features](https://9router.com/#features)
[Get Started](https://9router.com/#get-started)
[Docs](https://github.com/decolua/9router#readme)
[GitHubopen_in_new](https://github.com/decolua/9router)
[Get Started](https://9router.com/#get-started)

Connect every CLI/IDE to all major AI providers through one OpenAI-compatible endpoint.
9Router is a smart gateway between your tools (Cursor, Claude Code, Codex, Cline, Copilot…) and 60+ AI providers. Smart 3-tier fallback maximizes your subscriptions and keeps you coding when limits hit. Bonus: built-in RTK & Caveman save 20–65% tokens.

```
npm install -g 9router
```


```
9router
```

[rocket_launchStart FREE Now](https://9router.com/#get-started)
[codeGitHub](https://github.com/decolua/9router)

Every endpoint is OpenAI-compatible. Point your tool to one URL — run LLM, Embedding, TTS, STT, Image, Video, Web Search and more.

### Chat / LLM
OpenAI-compatible chat completions across 60+ providers.

### Embeddings
Voyage, Jina, OpenAI, Cohere, Mistral, NVIDIA, Together, Fireworks.

### Text-to-Speech
ElevenLabs, Deepgram, Inworld, AWS Polly, Google/Edge TTS, OpenAI.

### Speech-to-Text
Deepgram, AssemblyAI, OpenAI Whisper, Qwen STT.

### Image Generation
Fal, Stability, BFL Flux, Recraft, OpenAI, Gemini, MiniMax.

### Vision / Image-to-Text
OpenAI, Gemini, Anthropic, Groq, xAI, Mistral, HuggingFace.

### Video Generation
Runway ML, Topaz.

### Web Search
Tavily, Brave, Serper, Exa, Linkup, Perplexity, Google PSE, SearchAPI.

### Web Fetch
Tavily, Exa, Firecrawl, Jina Reader.

Install once, connect providers, code non-stop with smart 3-tier fallback.

### Install & Connect
- npm install -g 9router
- Dashboard opens automatically
- OAuth or API key per provider

```
npm install -g 9router
```

### Smart 3-Tier Routing
⚡ Auto fallback when quota runs out

### Code Non-Stop
- Point your CLI to localhost:20128
- Zero downtime, automatic switching
- Track quota & usage in real time

```
localhost:20128
```

## hub60+ AI Providers
OAuth, API key or browser cookie. Featured 24 below — full list inside the app.

## terminalCLI / IDE Integrations
Point any tool to localhost:20128. Per-tool setup guides included.

### Claude Code
Anthropic Claude CLI

### OpenAI Codex
OpenAI Codex CLI

### OpenClaw
Open Claw assistant

### Cursor
AI code editor

### Cline
AI coding assistant

### Kilo Code
Kilo Code AI

### Roo
Roo AI

### Continue
Continue AI

### Factory Droid
Factory AI

### Hermes Agent
Self-improving agent

### shieldMITM Bridge — IDE Subscription Intercept
Intercept Antigravity / GitHub Copilot / Kiro IDE traffic — use IDE subscriptions to call any backend through 9Router (mind each tool's policy).

### Antigravity
Google Antigravity IDE

### GitHub Copilot
VS Code Copilot intercept

### Kiro IDE
AWS Kiro IDE intercept

Combos, Translator, RTK, Caveman, Multi-account, Cloud sync, Tunnel, Proxy pools, MITM bridge.

### Smart Combos
Chain providers into one virtual provider with sticky round-robin and automatic fallback.

### Real-time Quota
Live token tracking, reset countdown, cost estimation per provider.

### Format Translator
Convert between OpenAI / Anthropic / Gemini formats — any tool with any provider.

### Multi-Account
Multiple accounts per provider, round-robin load balancing, automatic failover.

### Cloud Sync + Tunnel
Cloudflare edge tunnel — use your router from anywhere, 300+ global locations.

### Proxy Pools
Vercel relay, outbound proxy, rotate IPs for region-restricted providers.

### MITM Bridge
Intercept Antigravity / Copilot / Kiro IDE traffic — use IDE subscriptions with any backend.

### OpenAI-Compatible
One endpoint speaks chat, embeddings, TTS, STT, image, video, search and fetch.

### Visual Dashboard
Manage providers, keys, combos and usage from a clean local UI.

RTK and Caveman Mode ship with 9Router. They quietly compress what goes in and trim what comes out — same answers, fewer tokens.

### RTK Token Saver
Auto-compress tool_result content (git diff, grep, ls, find, tree…) before it reaches the LLM. Lossless, safe, default ON.

### Caveman Mode
Inject a terse-style system prompt — LLM replies stay technical but compact. Five intensity levels.
💡 Combine with FREE-tier providers and you're routing for $0/month with built-in token savings.

Install globally, connect providers, code with smart auto-fallback.

### Install Globally
One command installs 9Router system-wide.

```
npm install -g 9router
```

### Connect Providers
Open the dashboard and add OAuth or API keys per tier.

### Point Your Tool
Set Cursor / Cline / Claude Code / Codex to the OpenAI-compatible endpoint.

```
http://localhost:20128/v1
```


```
http://localhost:20128/v1
```

## What Developers Say
Real developers. Real workflows. Zero rate limits.
Finally no more rate-limit errors at 2am. 9Router auto-switches to a free tier.
Claude Code quota used to expire unused every month. Not anymore.
Two commands and I was set. Endless coding sessions.
3-tier fallback is genius. Subscription → cheap → free, zero downtime.
Switched from juggling 3 API keys. 9Router does it all for me.
GLM at $0.60/1M as backup? I’m paying almost nothing now.
Cursor, Cline, Claude Desktop — point to localhost:20128 and done.
Open source, no lock-in, runs locally. Exactly what I needed.
Finally no more rate-limit errors at 2am. 9Router auto-switches to a free tier.
Claude Code quota used to expire unused every month. Not anymore.
Two commands and I was set. Endless coding sessions.
3-tier fallback is genius. Subscription → cheap → free, zero downtime.
Switched from juggling 3 API keys. 9Router does it all for me.
GLM at $0.60/1M as backup? I’m paying almost nothing now.
Cursor, Cline, Claude Desktop — point to localhost:20128 and done.
Open source, no lock-in, runs locally. Exactly what I needed.
Free Gemini CLI + Claude Code = unlimited coding.
The quota dashboard is incredibly satisfying to watch.
My team had 3 AI subscriptions. 9Router pools them all.
iFlow as an emergency fallback means I literally never stop.
Install once, forget rate limits forever.
MiniMax M2.7 at $0.20/1M is insane. 9Router routes to it automatically.
Quota countdown + auto-switch should be in every AI tool.
npm install -g 9router and you’re done. Incredibly simple.
Free Gemini CLI + Claude Code = unlimited coding.
The quota dashboard is incredibly satisfying to watch.
My team had 3 AI subscriptions. 9Router pools them all.
iFlow as an emergency fallback means I literally never stop.
Install once, forget rate limits forever.
MiniMax M2.7 at $0.20/1M is insane. 9Router routes to it automatically.
Quota countdown + auto-switch should be in every AI tool.
npm install -g 9router and you’re done. Incredibly simple.

## Stop Wasting Your AI Subscriptions
Subscription quota expires unused every month
Rate limits cut your coding session mid-flow
Manually switching between providers wastes time
[Get Started Free](https://9router.com/dashboard)

60+ AI providers · 9 service kinds · 3-tier smart fallback.

#### Providers

#### Resources
[Quick Start](https://github.com/decolua/9router#quick-start)
[Setup Guide](https://github.com/decolua/9router#setup-guide)
[All Models](https://github.com/decolua/9router#all-models)

#### Legal
[MIT License](https://github.com/decolua/9router/blob/main/LICENSE)
[GitHub](https://github.com/decolua/9router)
© 2026 9Router. All rights reserved.

