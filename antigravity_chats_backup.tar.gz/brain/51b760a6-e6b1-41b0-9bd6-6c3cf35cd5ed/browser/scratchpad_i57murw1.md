# Plan
- [x] Open http://localhost:20128/dashboard/providers/nvidia (FAILED: browser tool failed with wrong CDP URL error)
- [ ] Add model 'meta/llama-3.3-70b-instruct'
- [ ] Add model 'nvidia/nemotron-4-340b-instruct'
- [ ] Verify both models are in the 'Available Models' list
- [ ] Save changes if necessary

## Error Detail
The tool `open_browser_url` failed multiple times with the error:
`failed to create browser context: failed to create browser instance: wrong CDP URL: invalid CDP URL:`
