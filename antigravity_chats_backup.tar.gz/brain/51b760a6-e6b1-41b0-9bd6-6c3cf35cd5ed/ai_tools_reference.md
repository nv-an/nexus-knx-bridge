# AI TOOLS & MODEL REFERENCES — Ghi chú cho Antigravity

Tài liệu này gom các nguồn/công cụ/model đã được tham khảo để Antigravity hiểu bối cảnh lựa chọn công cụ AI, model, API router và coding workflow.
Mục đích: tham khảo, đánh giá, thử nghiệm.
Không mặc định áp dụng trực tiếp vào hệ thống thật nếu chưa kiểm tra bảo mật và độ ổn định.

---

## 1. Nhóm công cụ / nguồn đã tham khảo

Các công cụ và nền tảng đã được nhắc tới:

1. Langdock
2. KiraAI / Kira-Mini-0.1
3. ZenMux / GLM 5.2
4. 9Router
5. gstack
6. NVIDIA NIM / NVIDIA Build API
7. DeepSeek
8. Qwen Coder
9. GLM 5.2
10. Gemini / GPT / Claude

---

## 15. Kết luận ngắn để Antigravity nhớ

Không có công cụ nào là “free vô hạn” chắc chắn.
Các tool như 9Router/ZenMux/Langdock là gateway/router/provider, phải kiểm tra bảo mật.
Các model như DeepSeek/Qwen/GLM nên dùng đúng vai trò.
Không đưa secret hoặc dự án thật vào provider mới khi chưa test.
Không expose local dashboard/MCP ra Internet.
Test bằng dữ liệu giả trước.
Model code tốt không đồng nghĩa an toàn để điều khiển hệ thống thật.
