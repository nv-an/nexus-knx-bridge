# Kế hoạch Xoay API Key (Rotate Key)

Theo đúng quy định bảo mật mới sếp vừa ban hành, dù đây là thao tác đổi Key khẩn cấp theo yêu cầu của sếp, tôi vẫn lập danh sách các file sẽ tác động để sếp nắm rõ trước khi duyệt.

## Đánh giá tình trạng Key hiện tại
Sau khi tôi chạy lệnh `curl` kiểm tra toàn bộ 14 Key, phát hiện:
- Key cũ (`R208A`) đã bị Google khóa tạm thời (Lỗi HTTP 503).
- Hiện tại có 4 Key đang "khỏe mạnh" (HTTP 200). Tôi chọn Key có đuôi **`NH1oQ`** để đưa lên làm Key chính.

## Proposed Changes

### Thay đổi Cấu hình OpenClaw Gateway Systemd

Tôi sẽ cập nhật file cấu hình systemd của OpenClaw Gateway để thay đổi biến môi trường `GEMINI_API_KEY` và `GOOGLE_API_KEY` sang Key mới (`NH1oQ`).

#### [MODIFY] [10-gemini-key.conf](file:///home/an/.config/systemd/user/openclaw-gateway.service.d/10-gemini-key.conf)
- Đổi `GEMINI_API_KEY` thành `AQ.Ab8RN6JRxGpvaZiUmWwY1kKCzE--NuS_K1Ji_UhWQlamfNH1oQ`.
- Đổi `GOOGLE_API_KEY` thành `AQ.Ab8RN6JRxGpvaZiUmWwY1kKCzE--NuS_K1Ji_UhWQlamfNH1oQ`.

## Verification Plan
1. Sau khi sếp duyệt, tôi sẽ cập nhật file và tự động chạy `systemctl --user daemon-reload` + `systemctl --user restart openclaw-gateway`.
2. Kiểm tra lại bằng lệnh `openclaw agent` để đảm bảo bot kết nối mượt mà.

> [!IMPORTANT]
> Sếp bấm **Duyệt** để tôi tiến hành nhổ Key cũ, cắm Key mới vào ngay nhé!
