# Tính năng đọc trạng thái thiết bị KNX

Tính năng này sẽ cho phép người dùng hỏi trạng thái các thiết bị thông qua bot Zalo (ví dụ: "trạng thái các đèn trong nhà", "đèn trần đang bật hay tắt").

## User Review Required

> [!WARNING]
> Việc đọc trạng thái của nhiều thiết bị cùng lúc (ví dụ khi hỏi "trạng thái tất cả các đèn") có thể mất vài giây nếu có nhiều thiết bị, do hệ thống phải truy vấn (gửi lệnh `GroupValueRead`) tới từng thiết bị và chờ phản hồi trên bus KNX. 
> Hệ thống sẽ xử lý song song (concurrent) để tối ưu thời gian phản hồi nhanh nhất có thể.

## Open Questions

> [!IMPORTANT]
> 1. Khi hỏi trạng thái tất cả các thiết bị, bạn có muốn bot chỉ liệt kê những thiết bị **Đang Bật** để tin nhắn ngắn gọn hơn không, hay liệt kê toàn bộ (cả Bật và Tắt)?
> 2. Có thiết bị nào trong `devices.json` chưa được cấu hình `status_ga` (địa chỉ trạng thái) không? Nếu không có `status_ga`, bot sẽ báo "chưa được cấu hình".

## Proposed Changes

### Thay đổi trong `app.py`

#### [MODIFY] app.py
- **Thêm import**: Import hàm `read_group_value` từ thư viện `xknx.tools`.
- **Thêm hàm `read_knx_status`**: Viết một hàm bất đồng bộ (async function) gọi `read_group_value` để truy vấn trạng thái từ KNX bus an toàn, có bẫy lỗi và timeout.
- **Cập nhật parser `_parse_status_query`**: Bổ sung logic phân tích ngôn ngữ tự nhiên để bắt các câu hỏi liên quan tới "trạng thái", "đang bật hay tắt", "kiểm tra", áp dụng cho 1 thiết bị cụ thể hoặc tất cả thiết bị.
- **Cập nhật hàm `agent_command`**: 
  - Thêm luồng xử lý mới: Khi phát hiện câu hỏi trạng thái, bot sẽ gọi `read_knx_status`.
  - Nếu hỏi 1 thiết bị: Đọc `status_ga` (và `brightness_status_ga` nếu có) để trả lời chi tiết.
  - Nếu hỏi nhiều thiết bị: Dùng `asyncio.gather` để đọc đồng thời trạng thái của tất cả các thiết bị có hỗ trợ `status_ga`, sau đó tổng hợp thành danh sách báo cáo.

## Verification Plan

### Automated Tests
- Kiểm tra tính hợp lệ của hàm parse bằng cách đưa thử các câu lệnh: "đèn trần đang bật hay tắt", "trạng thái các đèn".

### Manual Verification
- Chạy thử `app.py` với cấu hình kết nối KNX. Gửi lệnh qua API hoặc Zalo bot và kiểm tra xem có phản hồi trạng thái từ KNX Gateway về đúng không.
