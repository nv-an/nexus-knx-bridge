# Nhiệm vụ: Thêm tính năng đọc trạng thái KNX

- [x] Import `read_group_value` từ thư viện `xknx.tools`
- [x] Thêm hàm async `read_knx_status(ga, value_type)`
- [x] Cập nhật hàm parse `_parse_status_query`
- [x] Thêm luồng xử lý trạng thái trong hàm `agent_command`
- [x] Liệt kê tất cả trạng thái thiết bị hoặc trạng thái chi tiết của một thiết bị.
